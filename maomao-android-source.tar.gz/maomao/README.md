# Maomao

**Maomao is a native Android control app for XINCLI running inside Termux.** The Android app owns the interface; Termux remains the local runtime. No Alpine, Ubuntu, PRoot, or second Linux distribution is installed.

> Current status: early implementation (0.1.0). Chat/session restore, a loopback-only bridge, approval prompts, a memory telemetry hook, workspace listing, a basic terminal, and Git status are scaffolded. The full feature plan is tracked in [`ROADMAP.md`](ROADMAP.md).

## Architecture

```text
Maomao (Kotlin + Jetpack Compose)
        │ authenticated TCP on 127.0.0.1
        ▼
Termux bridge (Node.js, user-owned Termux home)
        ├── XINCLI CLI (stream-json stdin/stdout)
        ├── memory telemetry preload (read-only)
        ├── terminal command runner
        ├── workspace file listing
        └── git status
```

- The app uses Termux's `RUN_COMMAND` service to start a small local bridge.
- The bridge binds only to `127.0.0.1` and authenticates the app using a random per-install token.
- XINCLI is launched with `--print --input-format stream-json --output-format stream-json --verbose`.
- Existing conversations use XINCLI's `--resume <session-id>`; branching uses `--fork-session`.
- The app never adds `--dangerously-skip-permissions`. Tool calls remain approval-based.
- The memory preload reports `process.memoryUsage()` and V8 heap limits. It does not kill or patch the XINCLI process.

## Requirements

- Android 8.0 or newer (minSdk 26).
- Termux installed from a trusted source and configured with Node.js.
- XINCLI installed as `~/.local/bin/xincli` using its existing installer.
- Termux `allow-external-apps=true` and the Android `Run commands in Termux environment` permission granted to Maomao.

One-time Termux setting in `~/.termux/termux.properties`:

```properties
allow-external-apps = true
```

The `RUN_COMMAND` permission is a user-granted Android permission. The app cannot silently grant it.

## Build

Use Android Studio with JDK 17 and Android SDK Platform 36, or run:

```bash
gradle :app:assembleDebug
gradle :app:testDebugUnitTest
```

A GitHub Actions workflow builds the debug APK and runs unit tests on pushes and pull requests.

## Safety notes

The built-in terminal executes commands as the Termux user. Treat commands and project directories with the same care as a normal shell. Only connect to the bridge from the local app; do not expose its loopback ports through a tunnel. The bridge token is stored in app-private preferences and is not written to the repository.

## Inspiration and attribution

Maomao adapts product patterns, not copied source code, from these independent projects:

- [Aider](https://github.com/Aider-AI/aider) — repository-map approach and test/repair loops.
- [Cline](https://github.com/cline/cline) — human approvals, checkpoint/undo direction, and controlled tool execution.
- [Goose](https://github.com/block/goose) — reusable recipes and task-oriented workflows.
- [OpenHands](https://github.com/All-Hands-AI/OpenHands) — separation between agent runtime, event transport, and user interface.
- [Termux RUN_COMMAND Intent](https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent) — supported external-app integration path.

Maomao does not bundle or redistribute those projects' source code.
